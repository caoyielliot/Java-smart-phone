coin class is used to define coin's properties and methods;
test01 class is used to get the initial face of coin, get the final times of heads and tails, get the each tossed face of coin 