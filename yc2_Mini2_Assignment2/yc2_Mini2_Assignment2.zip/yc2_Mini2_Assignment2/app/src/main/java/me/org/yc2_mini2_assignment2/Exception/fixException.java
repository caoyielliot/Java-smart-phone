package me.org.yc2_mini2_assignment2.Exception;

import java.util.Scanner;

/**
 * this class is used to fix the custom exception
 * Created by caoyi on 16/3/20.
 */
public class fixException {
    public int fixInvalidNumberException1(){
        return 0;

    }
    public double fixInvalidNumberException2(){


        return 0;
    }
}
