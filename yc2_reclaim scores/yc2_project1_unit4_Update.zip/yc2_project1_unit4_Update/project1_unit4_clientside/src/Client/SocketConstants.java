package Client;

public class SocketConstants {
  static int PORT_NUMBER =8088;
  static String PORT_IP="localhost";
  boolean DEBUG = false; 
}
