package Adapter;

import scale.EditOptions;

/**
 * 
 * @author Yi Cao
 * @
 */
public class BuildAuto extends proxyAutomobile implements UpdateAuto,CreateAuto, EditThreads{

}