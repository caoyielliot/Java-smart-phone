package Adapter;
// FixAuto interface 
public interface FixAuto {
     
   public void fix(int errno);
}
