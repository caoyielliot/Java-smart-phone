package server;

public class SocketConstants {
  static int PORT_NUMBER =8088;
  static String PORT_IP="localhost";
  static boolean DEBUG=false;
}
