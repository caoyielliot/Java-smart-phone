package Adapter;

import scale.EditOptions;
import server.AutoServer;

/**
 * 
 * @author Yi Cao
 * @
 */
public class BuildAuto extends proxyAutomobile implements UpdateAuto,CreateAuto, EditThreads, AutoServer{


}