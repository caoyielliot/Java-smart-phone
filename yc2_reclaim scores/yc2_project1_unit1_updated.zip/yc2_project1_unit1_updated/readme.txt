the step of design the configuration of the car:
1. Design class OptionSet and Option 
2. Design the Automotive Class 
3. Design the FileIO class 
4. Test the FileIO buildAutoObject function;
5. Serialization and Deserialization
6. Design driver class and test 
