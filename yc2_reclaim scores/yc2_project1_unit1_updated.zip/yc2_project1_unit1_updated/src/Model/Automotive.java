package Model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Set;



public class Automotive implements Serializable{ // This class will represent the Model. String name;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;// the name of model
	private OptionSet opset[];//the possible optset of the model
    private float baseprice;
	//constructor
	public  Automotive(String name,float baseprice, int setSize, int[] optSize) {
		this.baseprice=baseprice;
		this.name=name;
		opset=new OptionSet[setSize];
		for(int i=0;i<setSize;i++ ){
			opset[i]=new OptionSet(optSize[i]);
		}
		
		
	}
	//constructor without parameter
	public Automotive() {
		super();
	}
    //get Auto name
	public String getName() {
		return name;
	}
     //get option set by its index
	public OptionSet getOpsetByindex(int index) {
		//the index is the index number of the attribute
		return opset[index];
	}
	//get the option set by itsname
	public OptionSet getOpsetByName(String name){
		int i=0;
		while(!(opset[i].getName().equals(name))) ++i;
		if(i<opset.length){
			return opset[i];
		}else{
			return null;
		}
	}
	//get the baseprice
    public double getBaseprice(){
    	return baseprice;
    }
    // find the option set By name
   public int findOpsetByName(String name){
	   int index=0;
	   while(!(opset[index].getName().equals(name))){
		   ++index;
	   }
	   return index;
   }
   //set the name of auto
	public void setName(String name) {
		this.name = name;
	}
   //set the option set
	public void setOpset(OptionSet[] opset) {
		this.opset = opset;
	}
	//set the option set name
	public void setOpSetName(int index, String name){
		opset[index].setName(name);
	}
    //set the option
   public void setOpts(int setIndex, int optIndex, String opName, float opPrice){
	   opset[setIndex].setOpt(optIndex, opName, opPrice);
   }
	//set the base price
	public void setBaseprice(float baseprice) {
		this.baseprice = baseprice;
	}
    //delete the option set by the optionset name
    public void deleteOptionSetByName(String name){
    	 
    	  opset[findOpsetByName(name)]=null;
    }	
    //delete the option set by the index
    public void deletOptionSetByIndex(int setIndex, int opindex){
    	  opset[setIndex].deleteOptByIndex(opindex);
    }
    //delete the option  by its name
    public void delteOptionSetByName(int setIndex, String optName){
    	opset[setIndex].deleteOptByName(optName);
    	
    }
    //delete the option by its name
    public void deletOptionSetByName(String setName, String optName){
    	opset[findOpsetByName(setName)].deleteOptByName(optName);
    }
    //delete the option by its index 
    public void deletOptionSetByName(String setName, int index){
    	opset[findOpsetByName(setName)].deleteOptByIndex(index);
    }
    //update the option set 
    public void updateOptset(int optIndex,String setname,float price,String optName){
    	int index=findOpsetByName(setname);
    	opset[index].setOpt(optIndex, optName, price);
    }
    //print the car info
   public void printCar(){
	   System.out.println("car name:"+name);
	   for(int i=0;i<opset.length;i++){
		   System.out.println("the OptionSet name:"+opset[i].getName());
		   for(int j=0;j<opset[i].getOpt().length;j++){
			   System.out.println(opset[i].getOpt()[j]);
		   }
	   }
	   
	   
   }

    
	
}
