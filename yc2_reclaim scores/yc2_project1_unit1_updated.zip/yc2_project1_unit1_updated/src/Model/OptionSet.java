package Model;

import java.io.Serializable;
import java.util.Arrays;

 public class OptionSet implements Serializable{
	/**
	 * this class describe the option set details
	 */
	private static final long serialVersionUID = 1L;
	private Option opt[];//possible options of each attribute
	private String name;//the name of car attribute
//constructor
	 protected OptionSet(String n, int size) {
		this.opt = new Option[size];
		this.name = n;
		for (int i = 0; i < size; i++) {
			opt[i] = new Option();
		}
	 
	}
	 //constructor with opset size
	 protected OptionSet(int size) {
			this.opt = new Option[size];
			for (int i = 0; i < size; i++) {
				opt[i] = new Option();
			}
		 
		}
    //constructor with no parameter
	protected  OptionSet() {
		super();
	}
	//get the option by its name
	protected Option getOptionByName(String name){
		int i=0;
		while(!(opt[i].name.equals(name))) ++i;
		return opt[i];
	}
	//get the option by its index
	protected Option getOptionByIndex(int index){
		return opt[index];
	}
	//find the the option index with its name
	protected int findOptionByName(String name){
		int index = 0;
		while(!(opt[index].name.equals(name))) ++index;
		if(index<opt.length){
			return index;
		}
		return -1;
	}
	
	    
       //delete the option by its index
		protected  void deleteOptByIndex(int index){
			opt[index]=null;
			
		}
		//delete the option by itsname
		protected void deleteOptByName(String name){
			int i=0;
			while(!(opt[i].name.equals(name))){
				++i;
			}
			opt[i]=null;
			
		}
		
		
		//get the option array
		protected Option[] getOpt() {
			return opt;
		}
        //set the option
		protected void setOpt(Option[] opt) {
			this.opt = opt;
		}
		//set the option name and price
		protected  void setOpt(int optSize, String opName, float opPice) {
			opt[optSize].setName(opName);
			opt[optSize].setPrice(opPice);
		}
       // get the optionset name
		protected String getName() {
			return name;
		}
        //set the option set name
		protected void setName(String name) {
			this.name = name;
		}
		//update the option price
        protected void updateOpt(String optName,float price){
        int optIndex=findOptionByName(optName);
        opt[optIndex].setName(optName);
        opt[optIndex].setPrice(price);
        }
		@Override
		public String toString() {
			return "OptionSet [opt=" + Arrays.toString(opt) + ", name=" + name + "]";
		}


		protected class Option implements Serializable{
		    /**
			 * this class includes the details of option
			 */
			private static final long serialVersionUID = 1L;
			private String name;// name of the option
			private float price;//the price of option
			//get the option name
			protected String getName() {
				return name;
			}
			//set the option name
			protected void setName(String name) {
				this.name = name;
			}
			//get the option price
			protected float getPrice() {
				return price;
			}
			//set the option price
			protected void setPrice(float price) {
				this.price = price;
			}
			//constructor
			protected Option(String name, float price) {
				super();
				this.name = name;
				this.price = price;
			}
			//constructor
			protected Option() {
				this("no Name",0);
				
			}
			@Override
			public String toString() {
				return "Option [name=" + name + ", price=" + price + "]";
			}
		}


		
       	
       	
       }
     
     
     
     
     
     
     
	
