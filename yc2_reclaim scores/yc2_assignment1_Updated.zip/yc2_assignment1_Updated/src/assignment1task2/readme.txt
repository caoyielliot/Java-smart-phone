in test01, we could input the purchased time and parking time as follows:
"121 60"
and it would output the results. If the car is illegal, it would output the car's info, the police info and the amount of fine. If the car is not illegal, it would out as "the car is not illegal".
The while loop is used in the test01, we could test any times we want.
