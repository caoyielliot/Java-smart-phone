1. the interface "Counting" is used to define the function of Statistics
2. the abstract class People is used to describe the Students 
3. If the input students' number is greater than 40, then it would throw my custom exception"TooManyStudents" and it would output the first 40 students. If number is smaller than 40, it  output normally.

